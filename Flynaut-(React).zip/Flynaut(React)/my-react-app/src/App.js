import logo from './logo.svg';
import './App.css';
import ClassComponent from './Components/ClassComponent';
import FunctionComponent from './Components/FunctionComponent';
import AllExampleComponent from './Components/AllExampleComponent'
import ScrollIntoDiv from './Components/ScrollIntoDiv';

const App: React.FC = () => {
  return (
    <div>
      <ClassComponent name="Akshay" />
      <FunctionComponent name="Flynaut" />
      <AllExampleComponent />
      <ScrollIntoDiv/>
    </div>
  );
};

export default App;
