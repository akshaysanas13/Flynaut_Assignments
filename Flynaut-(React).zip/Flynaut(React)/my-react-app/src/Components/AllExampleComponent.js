import React, { useState, useEffect, useCallback, useContext } from 'react';

// Example of useState
const Counter = () => {
  const [count, setCount] = useState(0);

  const increment = () => {
    setCount(prevCount => prevCount + 1);
  };

  return (
    <div>
      <p className='fs-4'> <span className='fs-3'>Count:</span> {count}</p>
      <button onClick={increment} className='btn btn-success'>Increment</button>
    </div>
  );
};

// Example of useEffect
const Timer = () => {
  const [time, setTime] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setTime(prevTime => prevTime + 1);
    }, 1000);

    return () => {
      clearInterval(interval);
    };
  }, []); // Empty dependency array to run effect only once on component mount

  return <p className='fs-5'>Time: {time}</p>;
};

// Example of useCallback
const Button = () => {
  const handleClick = useCallback(() => {
    console.log('Button clicked!');
  }, []); // Empty dependency array as callback does not depend on any values

  return <button onClick={handleClick} className='btn btn-info'>Click Me</button>;
};

// Example of useContext
const ThemeContext = React.createContext();

const App = () => {
  const theme = 'Light';

  return (
    <ThemeContext.Provider value={theme}>
      <Toolbar />
    </ThemeContext.Provider>
  );
};

const Toolbar = () => {
  const theme = useContext(ThemeContext);

  return <div className='fs-5'>Current Theme: {theme}</div>;
};

export default function ExampleComponent() {
  return (
    <div className='container text-start mt-3'>
      <Counter />
      <Timer />
      <Button />
      <App />
    </div>
  );
}
