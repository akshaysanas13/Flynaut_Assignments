import React, { Component } from 'react';
import '../classComponent.css';

// Props interface
interface ClassProps {
  name: string;
}

// Class component
class ClassComponent extends Component<ClassProps> {
  render() {
    return <h1 Class="font  text-center mt-3" >Hello, {this.props.name}!</h1>;
  }
}

export default ClassComponent;
