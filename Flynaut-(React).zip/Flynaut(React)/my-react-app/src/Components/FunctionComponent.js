import React, { useState, useEffect, useCallback, useContext } from 'react';
import '../functionComponent.css';

interface FunctionProps {
  name: string;
}

const FunctionComponent: React.FC<FunctionProps> = ({ name }) => {
   

  return (
    <div>
      <h1 class=" h-1 text-center ">Welcome at ,<span class="company">{name}!</span> </h1>
       
    </div>
  );
};

export default FunctionComponent;
