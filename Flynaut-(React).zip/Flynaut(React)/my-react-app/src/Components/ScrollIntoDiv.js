import React, { useRef } from 'react';
import '../scrollBar.css'

const ScrollIntoDiv = () => {
  const divRef = useRef(null);

  const scrollToDiv = () => {
    divRef.current.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className='container text-start'>
      <button className='btn btn-primary' onClick={scrollToDiv}>Scroll to Div</button>
      <div style={{ height: '200px', overflow: 'auto'  }}>
        <div style={{ height: '1000px' }}></div>
        <div ref={divRef} className='fs-5 scrollBar mt-3' >Scroll to this Div</div>
        <div style={{ height: '800px' }}></div>
      </div>
    </div>
  );
};

export default ScrollIntoDiv;
