// Function to find duplicate values in two arrays
function findDuplicates() {
    const arr1 = document.getElementById("arr1").value.split(",");
    const arr2 = document.getElementById("arr2").value.split(",");
    const printValues=document.getElementById("sameValue")

  // Create an empty object to store unique values from the first array
  let uniqueValues = {};

  // Iterate over the elements of the first array
  for (let i = 0; i < arr1.length; i++) {
    // Store each element as a key in the object with a value of true
    uniqueValues[arr1[i]] = true;
  }
   

  // Create an empty array to store the duplicate values
  let duplicates = [];

  // Iterate over the elements of the second array
  for (let i = 0; i < arr2.length; i++) {
    // Check if the current element exists as a key in the object
    if (uniqueValues[arr2[i]]) {
      // If it does, push the element into the duplicates array
      duplicates.push(arr2[i]);
    }
  }

  // Return the array of duplicate values
//   return duplicates;

  printValues.innerHTML = ` Duplicates values from two array's is : ${duplicates}`
}


// const duplicates = findDuplicates(arr1, arr2);
// console.log("Duplicate values:", duplicates);
