function manipulateObjects() {
    // Create an object obj1 with a property "greeting" set to "hello"
    let obj1 = { "greeting": "hello" };
  
    // Assign the reference of obj1 to obj2
    let obj2 = obj1;
  
    // Update the value of the "greeting" property in obj1 to "Bye"
    obj1["greeting"] = "Bye";
  
    // Log the updated obj1 and obj2 to the console
    console.log(obj1);
    console.log(obj2);
  }
  