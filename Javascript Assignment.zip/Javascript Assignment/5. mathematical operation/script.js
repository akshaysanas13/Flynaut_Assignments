const maths=()=>{
    // To retrieve values ​​from an HTML file
    const a=Number(document.getElementById("num1").value)
    const b = Number(document.getElementById("num2").value)

    // create a new variable for storing mathematical operations
    let calculate= (a+b)/2;

    //print calculate in the paragraph of html code

    const print=document.getElementById("print").innerHTML=`calculation of (${a}+${b})/2 = ${calculate}`

}